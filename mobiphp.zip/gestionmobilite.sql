-- phpMyAdmin SQL Dump
-- version 4.7.0
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le :  ven. 30 mars 2018 à 19:00
-- Version du serveur :  5.7.17
-- Version de PHP :  5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `gestionmobilite`
--

-- --------------------------------------------------------

--
-- Structure de la table `compatible`
--

CREATE TABLE `compatible` (
  `codeCours1` int(11) NOT NULL,
  `codeCours2` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `composercontrat`
--

CREATE TABLE `composercontrat` (
  `idContrat` int(11) NOT NULL,
  `codeCours` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `contrats`
--

CREATE TABLE `contrats` (
  `idContrat` int(11) NOT NULL,
  `duree` int(11) NOT NULL,
  `etatContrat` varchar(30) NOT NULL,
  `ordre` varchar(100) NOT NULL,
  `codeDip` int(11) NOT NULL,
  `intituleP` varchar(100) NOT NULL,
  `refDemMob` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `cours`
--

CREATE TABLE `cours` (
  `CodeCours` int(11) NOT NULL,
  `libelleCours` varchar(50) NOT NULL,
  `nbEcts` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='a';

--
-- Déchargement des données de la table `cours`
--

INSERT INTO `cours` (`CodeCours`, `libelleCours`, `nbEcts`) VALUES
(2, 'Cours de PHP et JSP avec M Sanchez', 999999999),
(3, 'Cours de réseau', 40),
(4, 'Systèmes informatiques organisés', 120);

-- --------------------------------------------------------

--
-- Structure de la table `demandemobilites`
--

CREATE TABLE `demandemobilites` (
  `refDemMob` varchar(100) NOT NULL,
  `dateDepotDemMob` date NOT NULL,
  `etatDemMob` varchar(100) NOT NULL,
  `numEtudiant` int(11) NOT NULL,
  `codeDip` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `demandesfinancieres`
--

CREATE TABLE `demandesfinancieres` (
  `RefDemandeFin` varchar(10) NOT NULL,
  `DateDepotDemFin` date NOT NULL,
  `EtatDemFin` varchar(30) NOT NULL,
  `MontantAccorde` double NOT NULL,
  `idContrat` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `diplomes`
--

CREATE TABLE `diplomes` (
  `codeDip` int(11) NOT NULL,
  `intituleDip` varchar(100) NOT NULL,
  `adresseWebD` varchar(255) NOT NULL,
  `niveau` varchar(30) NOT NULL,
  `nomU` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `diplomes`
--

INSERT INTO `diplomes` (`codeDip`, `intituleDip`, `adresseWebD`, `niveau`, `nomU`) VALUES
(3, 'BTS SIO', 'http://ozenne.entmip.fr/les-formations/sections-de-techniciens-superieurs/bts-services-informatiques-aux-organisations/', 'Bac +2', 'Lycee Ozenne'),
(5, 'DUT RT', 'http://formations.univ-grenoble-alpes.fr/fr/catalogue/dut-diplome-universitaire-de-technologie-CB/sciences-technologies-sante-STS/dut-reseaux-et-telecommunications-program-dut-reseaux-et-telecommunications.html', 'Bac +2', 'Universite Grenobles Alpes'),
(6, 'LPRO RTAI', 'http://www.rtai.fr', 'Bac +3', 'Universite Toulouse 1 Capitole');

-- --------------------------------------------------------

--
-- Structure de la table `etudiants`
--

CREATE TABLE `etudiants` (
  `numEtudiant` int(11) NOT NULL,
  `nomEt` varchar(50) NOT NULL,
  `prenomEt` varchar(50) NOT NULL,
  `email` varchar(255) NOT NULL,
  `cv` varchar(150) NOT NULL,
  `codeDip` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `etudiants`
--

INSERT INTO `etudiants` (`numEtudiant`, `nomEt`, `prenomEt`, `email`, `cv`, `codeDip`) VALUES
(3, 'Miniggio', 'Pierre', 'pierre.miniggio@gmail.com', 'http://miniggiodev.fr/docs/cv-Pierre-Miniggio.pdf', 5),
(4, 'Meziere', 'Benjamin', 'benjamin.meziere31@gmail.com', 'http://www.404cvnotfound.fr', 3),
(5, 'Ancien eleve', 'RTAI', 'rtai.rtai@rtai.rtai', 'http://www.rtai.fr', 6);

-- --------------------------------------------------------

--
-- Structure de la table `impliqueu`
--

CREATE TABLE `impliqueu` (
  `nomU` varchar(100) NOT NULL,
  `intituleP` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `progdiplome`
--

CREATE TABLE `progdiplome` (
  `codeCours` int(11) NOT NULL,
  `codeDip` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `progdiplome`
--

INSERT INTO `progdiplome` (`codeCours`, `codeDip`) VALUES
(4, 3),
(3, 5),
(2, 6);

-- --------------------------------------------------------

--
-- Structure de la table `programmes`
--

CREATE TABLE `programmes` (
  `intituleP` varchar(100) NOT NULL,
  `explication` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `programmes`
--

INSERT INTO `programmes` (`intituleP`, `explication`) VALUES
('Programme1', 'Je suis un programme'),
('Programme2', 'Je suis un deuxieme programme');

-- --------------------------------------------------------

--
-- Structure de la table `universites`
--

CREATE TABLE `universites` (
  `nomU` varchar(100) NOT NULL,
  `adressePostaleU` varchar(200) NOT NULL,
  `adresseWebU` varchar(255) NOT NULL,
  `adresseElectU` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `universites`
--

INSERT INTO `universites` (`nomU`, `adressePostaleU`, `adresseWebU`, `adresseElectU`) VALUES
('Lycee Ozenne', '9 Rue Merly 31000 Toulouse', 'http://ozenne.entmip.fr', 'contact@ozenne.entmip.fr'),
('Universite Grenobles Alpes', '621 Avenue Centrale 38400 Saint-Martin-d-Heres', 'https://www.univ-grenoble-alpes.fr', 'contact@univ-grenoble-alpes.fr'),
('Universite Toulouse 1 Capitole', '2 Rue du Doyen-Gabriel-Marty 31042 Toulouse Cedex 9', 'http://www.ut-capitole.fr', 'contact@ut-capitole.fr');

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `compatible`
--
ALTER TABLE `compatible`
  ADD PRIMARY KEY (`codeCours1`,`codeCours2`),
  ADD KEY `codeCours2` (`codeCours2`);

--
-- Index pour la table `composercontrat`
--
ALTER TABLE `composercontrat`
  ADD PRIMARY KEY (`idContrat`,`codeCours`),
  ADD KEY `codeCours` (`codeCours`);

--
-- Index pour la table `contrats`
--
ALTER TABLE `contrats`
  ADD PRIMARY KEY (`idContrat`),
  ADD KEY `codeDip` (`codeDip`),
  ADD KEY `intituleP` (`intituleP`),
  ADD KEY `refDemMob` (`refDemMob`);

--
-- Index pour la table `cours`
--
ALTER TABLE `cours`
  ADD PRIMARY KEY (`CodeCours`);

--
-- Index pour la table `demandemobilites`
--
ALTER TABLE `demandemobilites`
  ADD PRIMARY KEY (`refDemMob`),
  ADD KEY `numEtudiant` (`numEtudiant`),
  ADD KEY `codeDip` (`codeDip`);

--
-- Index pour la table `demandesfinancieres`
--
ALTER TABLE `demandesfinancieres`
  ADD PRIMARY KEY (`RefDemandeFin`),
  ADD KEY `idContrat` (`idContrat`);

--
-- Index pour la table `diplomes`
--
ALTER TABLE `diplomes`
  ADD PRIMARY KEY (`codeDip`),
  ADD KEY `nomU` (`nomU`);

--
-- Index pour la table `etudiants`
--
ALTER TABLE `etudiants`
  ADD PRIMARY KEY (`numEtudiant`),
  ADD KEY `codeDip` (`codeDip`);

--
-- Index pour la table `impliqueu`
--
ALTER TABLE `impliqueu`
  ADD PRIMARY KEY (`nomU`,`intituleP`),
  ADD KEY `intituleP` (`intituleP`);

--
-- Index pour la table `progdiplome`
--
ALTER TABLE `progdiplome`
  ADD PRIMARY KEY (`codeCours`,`codeDip`),
  ADD KEY `codeDip` (`codeDip`);

--
-- Index pour la table `programmes`
--
ALTER TABLE `programmes`
  ADD PRIMARY KEY (`intituleP`);

--
-- Index pour la table `universites`
--
ALTER TABLE `universites`
  ADD PRIMARY KEY (`nomU`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `contrats`
--
ALTER TABLE `contrats`
  MODIFY `idContrat` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT pour la table `cours`
--
ALTER TABLE `cours`
  MODIFY `CodeCours` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT pour la table `diplomes`
--
ALTER TABLE `diplomes`
  MODIFY `codeDip` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT pour la table `etudiants`
--
ALTER TABLE `etudiants`
  MODIFY `numEtudiant` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `compatible`
--
ALTER TABLE `compatible`
  ADD CONSTRAINT `compatible_ibfk_1` FOREIGN KEY (`codeCours1`) REFERENCES `cours` (`CodeCours`),
  ADD CONSTRAINT `compatible_ibfk_2` FOREIGN KEY (`codeCours2`) REFERENCES `cours` (`CodeCours`);

--
-- Contraintes pour la table `composercontrat`
--
ALTER TABLE `composercontrat`
  ADD CONSTRAINT `composercontrat_ibfk_1` FOREIGN KEY (`idContrat`) REFERENCES `contrats` (`idContrat`),
  ADD CONSTRAINT `composercontrat_ibfk_2` FOREIGN KEY (`codeCours`) REFERENCES `cours` (`CodeCours`);

--
-- Contraintes pour la table `contrats`
--
ALTER TABLE `contrats`
  ADD CONSTRAINT `contrats_ibfk_1` FOREIGN KEY (`codeDip`) REFERENCES `diplomes` (`codeDip`),
  ADD CONSTRAINT `contrats_ibfk_2` FOREIGN KEY (`intituleP`) REFERENCES `programmes` (`intituleP`),
  ADD CONSTRAINT `contrats_ibfk_3` FOREIGN KEY (`refDemMob`) REFERENCES `demandemobilites` (`refDemMob`);

--
-- Contraintes pour la table `demandemobilites`
--
ALTER TABLE `demandemobilites`
  ADD CONSTRAINT `demandemobilites_ibfk_1` FOREIGN KEY (`numEtudiant`) REFERENCES `etudiants` (`numEtudiant`),
  ADD CONSTRAINT `demandemobilites_ibfk_2` FOREIGN KEY (`codeDip`) REFERENCES `diplomes` (`codeDip`);

--
-- Contraintes pour la table `demandesfinancieres`
--
ALTER TABLE `demandesfinancieres`
  ADD CONSTRAINT `demandesfinancieres_ibfk_1` FOREIGN KEY (`idContrat`) REFERENCES `contrats` (`idContrat`);

--
-- Contraintes pour la table `diplomes`
--
ALTER TABLE `diplomes`
  ADD CONSTRAINT `diplomes_ibfk_1` FOREIGN KEY (`nomU`) REFERENCES `universites` (`nomU`);

--
-- Contraintes pour la table `etudiants`
--
ALTER TABLE `etudiants`
  ADD CONSTRAINT `etudiants_ibfk_1` FOREIGN KEY (`codeDip`) REFERENCES `diplomes` (`codeDip`);

--
-- Contraintes pour la table `impliqueu`
--
ALTER TABLE `impliqueu`
  ADD CONSTRAINT `impliqueu_ibfk_1` FOREIGN KEY (`nomU`) REFERENCES `universites` (`nomU`),
  ADD CONSTRAINT `impliqueu_ibfk_2` FOREIGN KEY (`intituleP`) REFERENCES `programmes` (`intituleP`);

--
-- Contraintes pour la table `progdiplome`
--
ALTER TABLE `progdiplome`
  ADD CONSTRAINT `progdiplome_ibfk_1` FOREIGN KEY (`codeDip`) REFERENCES `diplomes` (`codeDip`),
  ADD CONSTRAINT `progdiplome_ibfk_2` FOREIGN KEY (`codeCours`) REFERENCES `cours` (`CodeCours`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
