<h3 class="red-text">Un étudiant a été supprimé!</h3>

<?php
include 'etudiants_vue.php';