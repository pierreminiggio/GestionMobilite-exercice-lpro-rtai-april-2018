<h3 class="blue-text">Un étudiant a été modifié!</h3>

<?php
include 'etudiants_vue.php';