<h3 class="green-text">Un étudiant a été ajouté!</h3>

<?php
include 'etudiants_vue.php';