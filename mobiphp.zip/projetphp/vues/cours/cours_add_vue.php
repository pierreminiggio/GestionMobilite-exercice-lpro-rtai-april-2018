<h3 class="green-text">Un cours a été ajouté!</h3>

<?php
include 'cours_vue.php';