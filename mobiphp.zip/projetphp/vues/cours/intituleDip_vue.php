<h1><?=$_POST['intituleDip']?> : les cours programmés</h1>
