<h3 class="blue-text">Un cours a été modifié!</h3>

<?php
include 'cours_vue.php';