<h3 class="red-text">Un cours a été supprimé!</h3>

<?php
include 'cours_vue.php';