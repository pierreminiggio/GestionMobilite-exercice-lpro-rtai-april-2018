<h3 class="blue-text">Un diplome a été modifié!</h3>

<?php
include 'diplomes_vue.php';