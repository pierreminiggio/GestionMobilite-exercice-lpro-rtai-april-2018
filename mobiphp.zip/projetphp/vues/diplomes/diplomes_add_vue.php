<h3 class="green-text">Un diplome a été ajouté!</h3>

<?php
include 'diplomes_vue.php';