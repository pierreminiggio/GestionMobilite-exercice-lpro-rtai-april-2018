<h3 class="red-text">Un diplome a été supprimé!</h3>

<?php
include 'diplomes_vue.php';