<h3 class="red-text">Une université a été supprimée!</h3>

<?php
include 'universites_vue.php';