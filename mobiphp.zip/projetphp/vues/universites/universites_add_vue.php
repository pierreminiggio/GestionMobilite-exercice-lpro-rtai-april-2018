<h3 class="green-text">Une université a été ajoutée!</h3>

<?php
include 'universites_vue.php';