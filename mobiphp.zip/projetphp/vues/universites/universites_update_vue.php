<h3 class="blue-text">Une université a été modifiée!</h3>

<?php
include 'universites_vue.php';