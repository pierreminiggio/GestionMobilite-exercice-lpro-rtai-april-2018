<h3 class="red-text">Un programme a été supprimé!</h3>

<?php
include 'programmes_vue.php';