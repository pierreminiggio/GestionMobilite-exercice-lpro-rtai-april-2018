<h3 class="blue-text">Un programme a été modifié!</h3>

<?php
include 'programmes_vue.php';