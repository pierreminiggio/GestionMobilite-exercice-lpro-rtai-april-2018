<h3 class="blue-text">Un contrat a été modifié!</h3>

<?php
include 'contrats_vue.php';