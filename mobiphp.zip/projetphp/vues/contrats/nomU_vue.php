<h1>Université : <?=$_POST['nomU']?></h1>
