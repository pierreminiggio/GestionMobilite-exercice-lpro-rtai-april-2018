<h3 class="green-text">Un contrat a été ajouté!</h3>

<?php
include 'contrats_vue.php';