<h3 class="red-text">Un contrat a été supprimé!</h3>

<?php
include 'contrats_vue.php';