/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modeles;

import Utiles.dbUtils;
import java.util.Vector;

/**
 *
 * @author Ssanchez
 */
public class CD {
    private int id;
    private String title;
    private String artist;
    private double price;
    private int quantity;

    /**
     * @return the id
     */
    public int getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * @return the title
     */
    public String getTitle() {
        return title;
    }

    /**
     * @param title the title to set
     */
    public void setTitle(String title) {
        this.title = title;
    }

    /**
     * @return the artist
     */
    public String getArtist() {
        return artist;
    }

    /**
     * @param artist the artist to set
     */
    public void setArtist(String artist) {
        this.artist = artist;
    }

    /**
     * @return the price
     */
    public double getPrice() {
        return price;
    }

    /**
     * @param price the price to set
     */
    public void setPrice(double price) {
        this.price = price;
    }

    /**
     * @return the quantity
     */
    public int getQuantity() {
        return quantity;
    }

    /**
     * @param quantity the quantity to set
     */
    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }
    
    public static Vector<CD> getCatalogue(){
        Vector<CD> cat = new Vector();
        
        java.sql.Connection c = dbUtils.connect();
        
        //D'abord le nombre d'albums
        String sql = "SELECT albumID,albumTitle, price, quantity, artistName ";
        sql += "FROM albums, artists ";
        sql += "Where albums.artistID = artists.artistID;";
        
        java.sql.ResultSet rs = null;
        rs = dbUtils.query(c, sql);
        CD cd = null;
        try{
            while (rs.next()){
                cd = new CD();
                cd.artist = rs.getString("artistName");
                cd.id = Integer.parseInt(rs.getString("albumID"));
                cd.price = Double.parseDouble(rs.getString("price"));
                cd.quantity = Integer.parseInt(rs.getString("quantity"));
                cd.title = rs.getString("albumTitle");
            
                cat.add(cd);
            }
            //Fermer le resultset
            rs.close();
        }catch (Exception e){
            //TODO
        }
        return cat;
    }
    
    public static CD getCD(int id){
        java.sql.Connection c = dbUtils.connect();
        
        //D'abord le nombre d'albums
        String sql = "SELECT albumID,albumTitle, price, quantity, artistName ";
        sql += "FROM albums, artists ";
        sql += "Where albums.artistID = artists.artistID ";
        sql += "and albums.albumID = " + id + ";";
        
        java.sql.ResultSet rs = null;
        rs = dbUtils.query(c, sql);
        CD cd = null;
        try{
            if (rs.first()){
                cd = new CD();
                cd.artist = rs.getString("artistName");
                cd.id = Integer.parseInt(rs.getString("albumID"));
                cd.price = Double.parseDouble(rs.getString("price"));
                cd.quantity = Integer.parseInt(rs.getString("quantity"));
                cd.title = rs.getString("albumTitle");
            }
            //Fermer le resultset
            rs.close();
        }catch (Exception e){
            //TODO
        }
        return cd;
    }
    
}
